package automationFramework;

public class Constant {
	
	/* Order Number text */
	public static String BrowserorderNumberText;

	/* Contact Details */
	public static String Email;
	public static String PhoneNumber;
	public static String Address;
	public static String ApartmentNumber;
	public static String AFirstName;
	public static String ALastName;
	
	
	
	

}
